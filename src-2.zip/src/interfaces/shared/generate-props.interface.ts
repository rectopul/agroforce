export interface IGenerateProps {
  name: string
  title: string
  value: string
}
