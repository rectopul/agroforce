import { prisma } from '../pages/api/db/db';

export class UsersPermissionsRepository {
  async create(Permission: object | any) {
    const Result = await prisma.users_permissions.createMany({ data: Permission });
    return Result;
  }

  async update(id: number, Data: Object) {
    const Result = await prisma.users_permissions.update({
      where: {
        id,
      },
      data: Data,
    });

    return Result;
  }

  async findAll(where: any) {
    const select = {
      id: true, name: true, cpf: true, login: true, telefone: true, avatar: true, status: true,
    };
    const Result = await prisma.users_permissions.findMany({ where, select });
    return Result;
  }

  async findAllByUser(userId: number | any) {
    const Result = await prisma.users_permissions.findMany({
      where: {
        userId,
        culture: { status: 1 },
      },
      select: {
        id: true,
        cultureId: true,
        profileId: true,
        status: true,
        culture: { select: { name: true, desc: true } },
      },
      distinct: ['cultureId'],
    });
    return Result;
  }

  async delete(where: object) {
    const Result = await prisma.users_permissions.deleteMany({
      where,
    });
    return Result;
  }

  async updateAllStatus(userId: any) {
    await prisma.$executeRaw`UPDATE users_permissions SET status = 0 WHERE userId = ${userId}`;
  }

  async queryRaw(idUser: any, cultureId: any) {
    await prisma.$executeRaw`UPDATE users_permissions SET status = 1 WHERE userId = ${idUser} AND cultureId = ${cultureId}`;
  }
}
